package com.watermakerhospital.control;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Kartin Wi-Fi agina baglanir (Android 10+: sistem onay penceresiyle) ve kartin kendi sundugu web arayuzunu uygulama icinde acar. */
public class MainActivity extends Activity {
    private WebView web;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (r.getUrl().toString().startsWith("retry://")) {
                    connect();
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
        });
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        connect();
    }

    private void connect() {
        release();
        if (Build.VERSION.SDK_INT < 29) {      // Android 8-9: aga elle baglanin, sonra sayfa acilir
            load();
            return;
        }
        WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
                .setSsid(Config.SSID)
                .setWpa2Passphrase(Config.PASS)
                .build();
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build();
        cb = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network n) {
                cm.bindProcessToNetwork(n);
                runOnUiThread(() -> load());
            }

            @Override
            public void onUnavailable() {       // ag bulunamadi / onay verilmedi: telefon zaten bagliysa yine de dene
                runOnUiThread(() -> load());
            }

            @Override
            public void onLost(Network n) {
                runOnUiThread(() -> showError());
            }
        };
        cm.requestNetwork(req, cb, 30000);
    }

    private void load() {
        web.loadUrl(Config.URL);
    }

    private void showError() {
        String html = "<html><body style='background:#050f16;color:#9fe8ff;font-family:monospace;padding:28px'>"
                + "<h2>Karta ulasilamadi</h2><p>Kartin acik oldugundan ve <b>" + Config.SSID + "</b> agina baglanabildiginizden emin olun.</p>"
                + "<p><a style='color:#4cd68a;font-size:20px' href='retry://now'>[ Tekrar dene ]</a></p></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private void release() {
        if (cb != null) {
            try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
            cb = null;
        }
        cm.bindProcessToNetwork(null);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        release();
        super.onDestroy();
    }
}
