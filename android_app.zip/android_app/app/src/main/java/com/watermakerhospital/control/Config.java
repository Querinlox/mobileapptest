package com.watermakerhospital.control;

/** Karttaki settings.toml ile AYNI olmali (WM_AP_SSID / WM_AP_PASS). Degistirdiyseniz burada da degistirip uygulamayi yeniden derleyin. */
public final class Config {
    public static final String SSID = "WaterMaker";
    public static final String PASS = "netatec5587";
    public static final String URL = "http://192.168.4.1/";
    private Config() {}
}
